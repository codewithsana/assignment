package controlstatement;

public class Dowhileodd {
	public static void main(String[] args) {
		int i=1;
		System.out.println("first 10 odd number\n");
		do {
			System.out.println(i);
			i=i+2;
		}while(i<=20);
	}
}
