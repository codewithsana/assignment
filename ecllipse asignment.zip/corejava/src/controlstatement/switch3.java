package controlstatement;

public class switch3 {
public static void main(String[] args) {
	int a=7;
	switch(a)
	{
	case 1:
		System.out.println("monday");
		break;
	case 2:
		System.out.println("tuesday");
		break;
	case 3:
		System.out.println("wednesday");
		break;
	case 7:
		System.out.println("thursday");
		break;
	case 5:
		System.out.println("friday");
		break;
	case 0:
		System.out.println("saturday");
		break;
	default:System.out.println("sunday");
	}
	
}
}
